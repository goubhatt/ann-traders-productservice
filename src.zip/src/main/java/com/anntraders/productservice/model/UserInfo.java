package com.anntraders.productservice.model;

public record UserInfo(String sub, String email, String username) {
}

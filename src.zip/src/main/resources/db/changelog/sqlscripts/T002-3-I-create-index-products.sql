CREATE INDEX IF NOT EXISTS idx_products_name ON anntraders.products(name);
CREATE INDEX IF NOT EXISTS idx_products_ownerid ON anntraders.products(ownerid);

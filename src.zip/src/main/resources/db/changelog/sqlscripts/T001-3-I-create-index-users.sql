CREATE INDEX IF NOT EXISTS idx_users_username ON anntraders.users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON anntraders.users(email);

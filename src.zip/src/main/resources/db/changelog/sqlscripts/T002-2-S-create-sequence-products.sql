-- Sequence for products table
CREATE SEQUENCE IF NOT EXISTS anntraders.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;